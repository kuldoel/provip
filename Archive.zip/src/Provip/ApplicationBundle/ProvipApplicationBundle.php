<?php

namespace Provip\ApplicationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProvipApplicationBundle extends Bundle
{
}
