<?php

namespace Provip\ProvipBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProvipProvipBundle extends Bundle
{
}
