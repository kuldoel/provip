<?php

namespace Provip\EventsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProvipEventsBundle extends Bundle
{
}
